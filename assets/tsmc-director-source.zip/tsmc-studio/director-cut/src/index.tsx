import React from 'react';import {registerRoot,Composition} from 'remotion';import {Film} from './Film';
registerRoot(()=> <Composition id="TSMCDirectorCut" component={Film} durationInFrames={840} fps={30} width={1920} height={1080}/>);
