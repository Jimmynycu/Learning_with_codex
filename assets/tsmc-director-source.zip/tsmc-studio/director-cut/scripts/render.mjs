import {bundle} from '@remotion/bundler';
import {openBrowser,selectComposition,renderStill,renderMedia} from '@remotion/renderer';
import path from 'node:path';
const mode=process.argv[2]??'stills';
const root=process.cwd();const inputProps={quality:mode==='draft'||mode==='transition'?.4:1};
console.log('Bundle',new Date().toISOString());
const serveUrl=await bundle({entryPoint:path.join(root,'director-cut/src/index.tsx'),publicDir:path.join(root,'public'),outDir:path.join(root,'director-cut/.bundle')});
const chromiumOptions={gl:'swangle'};
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',chromiumOptions});
try{
 const composition=await selectComposition({serveUrl,id:'TSMCDirectorCut',puppeteerInstance:browser,chromiumOptions,inputProps,timeoutInMilliseconds:120000});
 if(mode==='stills'||mode==='approval'){
  for(const frame of mode==='approval'?[175,375,555]:[45,175,285,375,465,555,675,795]){
   console.log('Frame',frame,new Date().toISOString());
   await renderStill({serveUrl,composition,puppeteerInstance:browser,chromiumOptions,inputProps,frame,output:path.join(root,`director-cut/evidence/${mode}-${frame}.png`),timeoutInMilliseconds:120000});
  }
 }else{
  let last=-1;
  await renderMedia({serveUrl,composition,puppeteerInstance:browser,chromiumOptions,inputProps,frameRange:mode==='repair'?[240,344]:mode==='transition'?[210,345]:undefined,everyNthFrame:mode==='draft'?3:1,outputLocation:path.join(root,mode==='draft'?'director-cut/output/review.mp4':mode==='transition'?'director-cut/output/transition.mp4':mode==='repair'?'director-cut/output/handoff-repair.mp4':'director-cut/output/tsmc-scale-of-possibility.mp4'),codec:'h264',crf:mode==='draft'?23:17,scale:mode==='draft'||mode==='transition'?.5:1,concurrency:2,timeoutInMilliseconds:120000,videoBitrate:undefined,x264Preset:'medium',onProgress:({progress,renderedFrames,encodedFrames})=>{const pct=Math.floor(progress*100);if(pct!==last){last=pct;console.log(JSON.stringify({percent:pct,renderedFrames,encodedFrames,at:new Date().toISOString()}))}}});
 }
}finally{await browser.close({silent:true})}
