"""Original 28-second score and sound design; deterministic, no sampled music."""
from pathlib import Path
import numpy as np
from scipy.signal import fftconvolve, butter, sosfilt
import wave,json
ROOT=Path(__file__).resolve().parents[1]; DEST=ROOT.parents[0]/'public/director-cut'
SR=48000;D=28;N=SR*D;rng=np.random.default_rng(20261004)
mix=np.zeros((N,2),dtype=np.float64);send=np.zeros_like(mix)
def times(d):return np.arange(round(d*SR))/SR
def hz(n):return 440*2**((n-69)/12)
def add(sig,start,gain=1,pan=0,wet=.2):
 k=round(start*SR)
 if k<0:sig=sig[-k:];k=0
 m=min(len(sig),N-k)
 if m<=0:return
 g=np.array([np.cos((pan+1)*np.pi/4),np.sin((pan+1)*np.pi/4)])*gain
 mix[k:k+m]+=sig[:m,None]*g;send[k:k+m]+=sig[:m,None]*g*wet

def pluck(note,start,gain=.10,pan=0,dur=1.6,bright=.24):
 t=times(dur);f=hz(note);env=(1-np.exp(-t*900))*np.exp(-t*4.8)
 s=(np.sin(2*np.pi*f*t)+bright*np.sin(2*np.pi*2*f*t)*np.exp(-t*6)+.06*np.sin(2*np.pi*3*f*t))*env
 add(s,start,gain,pan,.6)
 add(s,start+.375,gain*.22,-pan,.3)

def kick(start,gain=.45):
 t=times(.5);s=np.sin(2*np.pi*(43*t+2.1*(1-np.exp(-t*38))))*np.exp(-t*11)*(1-np.exp(-t*1000))
 add(s,start,gain,0,.04)

def tick(start,gain=.11,pan=0,metal=False):
 t=times(.13 if metal else .07);s=(np.sin(2*np.pi*1850*t)*.22+rng.normal(0,1,len(t))*.16)*np.exp(-t*(55 if metal else 100));add(s,start,gain,pan,.26)

def sweep(hit,dur=.8,gain=.1,pan=0):
 t=times(dur);s=sosfilt(butter(2,[600,5000],btype='bandpass',fs=SR,output='sos'),rng.normal(0,1,len(t)));env=np.sin(np.pi*t/dur)**2
 add(s*env,hit-dur*.8,gain,pan,.35)

def impact(hit,gain=.5):
 kick(hit,gain);t=times(2.0);s=np.sin(2*np.pi*(38*t+.4*(1-np.exp(-t*8))))*np.exp(-t*2.8)*(1-np.exp(-t*500));add(s,hit,gain*.35,0,.5);sweep(hit,1.1,.14)

# Seven harmonic phrases. Preserve a long, undisturbed final resolve.
chords=[[50,57,60,64,69],[50,57,60,64,69],[46,53,57,60,65],[53,60,64,67,72],[48,55,60,62,67],[50,57,60,64,69],[50,57,62,64,69]]
for phrase,notes in enumerate(chords):
 start=phrase*4;t=times(5.2);env=np.minimum(t/.65,1)*np.minimum((5.2-t)/1.3,1)
 for j,n in enumerate(notes):
  f=hz(n);sig=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*f*1.0015*t)+.09*np.sin(2*np.pi*2*f*t))*env
  add(sig,start,.022 if phrase==0 else .039,(j-2)/2.5,.55)
 if phrase>0:
  bt=times(3.95);envb=np.minimum(bt/.04,1)*np.minimum((3.95-bt)/.3,1)
  bass=(np.sin(2*np.pi*hz(notes[0]-12)*bt)+.1*np.sin(2*np.pi*hz(notes[0])*bt))*envb
  add(bass,start,.12 if phrase<4 else .16,0,.02)

# A shaped motif: a few notes at the start, a developed arpeggio, then release.
for beat in range(56):
 start=beat*.5;phrase=min(beat//8,6);notes=chords[phrase]
 if start<3.5:
  if beat in [1,3,6]:pluck(notes[beat%5]+12,start,.085,(-1)**beat*.35)
 elif start<24:
  pattern=[0,2,4,1,3,2,4,1];note=notes[pattern[beat%8]]+12
  pluck(note,start,.09 if start<16 else .12,(-1)**beat*.42)
  if 12<=start<23.5:pluck(notes[(beat+2)%5]+24,start+.25,.035,(-1)**(beat+1)*.55,bright=.12)
 if 4<=start<24:
  if start<12 and beat%2==0:kick(start,.26)
  elif 12<=start<24:kick(start,.33 if beat%4 else .48)
 if 8<=start<23.5 and beat%2:
  tt=times(.18);noise=sosfilt(butter(2,1400,btype='highpass',fs=SR,output='sos'),rng.normal(0,1,len(tt)));sn=(noise*.12+np.sin(2*np.pi*190*tt)*.23)*np.exp(-tt*30)
  add(sn,start,.25,.1,.3)
 if 12<=start<23.5:
  tt=times(.045);noise=np.diff(rng.normal(0,1,len(tt)),prepend=0)*np.exp(-tt*90);add(noise,start+.25,.016,(-1)**beat*.55,.08)
for hit in [3.5,8,10.5,14.5,16,21,24.5]:sweep(hit,.75,.13 if hit in [16,24.5] else .08)
for i,hit in enumerate([8,9,10.5,11,11.5,14.5,15,15.5]):tick(hit,.35,(-1)**i*.3,True)
for hit in [4,16,21,25]:impact(hit,.46)
for i,n in enumerate([62,69,74,76,81]):pluck(n,25+i*.035,.12-i*.013,(i-2)/3,dur=2.8,bright=.08)
# Wide, decaying algorithmic room (original noise IR), with early reflections.
L=round(SR*1.8);rt=np.arange(L)/SR
for ch in range(2):
 ir=rng.normal(0,1,L)*np.exp(-rt*4.8);ir=sosfilt(butter(2,4800,fs=SR,output='sos'),ir);ir*=.002
 for delay,gain in [(.029,.17),(.067,.1),(.113,.075),(.181,.05)]:ir[int((delay+ch*.004)*SR)]+=gain
 mix[:,ch]+=fftconvolve(send[:,ch],ir)[:N]
fade=np.minimum(np.arange(N)/SR/.05,1)*np.minimum((N-1-np.arange(N))/SR/1.0,1);mix*=fade[:,None]
mix=np.tanh(mix*.85);mix*=.90/max(np.max(np.abs(mix)),1e-9)
with wave.open(str(DEST/'score-premaster.wav'),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('<i2').tobytes())
beats={'duration':28,'fps':30,'bpm':120,'beats':[i/2 for i in range(56)],'hits':[{'time':3.5,'event':'wafer reveal sweep'},{'time':8,'event':'selected die lift'},{'time':10.5,'event':'package reveal'},{'time':11,'event':'layer separation'},{'time':11.5,'event':'upper layer settle'},{'time':14.5,'event':'assembly begins'},{'time':16,'event':'package locked / signal launch'},{'time':21,'event':'hero resolve'},{'time':25,'event':'brand chord'}]}
(ROOT/'beats.json').write_text(json.dumps(beats,indent=2));print({'seconds':D,'peak_before_mastering':float(np.max(np.abs(mix)))})
