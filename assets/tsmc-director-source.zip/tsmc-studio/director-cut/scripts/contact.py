from pathlib import Path
from PIL import Image,ImageDraw
import subprocess
ROOT=Path(__file__).resolve().parents[1];film=ROOT/'output/tsmc-scale-of-possibility.mp4'
# Full encoded output, with extra attention to the handoff and final transition.
times=[.8,2.2,3.6,5.8,7.8,8.7,9.6,10.6,12.6,14.8,16,18.8,21.8,24.4,25.1,27.5]
out=Image.new('RGB',(1920,4*292),'#0b0e12');d=ImageDraw.Draw(out)
for i,t in enumerate(times):
 p=ROOT/f'evidence/final-frame-{i:02d}.jpg';subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(film),'-frames:v','1','-q:v','2','-vf','scale=480:270',str(p)],check=True)
 out.paste(Image.open(p),(i%4*480,i//4*292));d.text((i%4*480+10,i//4*292+275),f'{t:04.1f} s',fill='#ddd')
out.save(ROOT/'evidence/final-contact.jpg',quality=94)
