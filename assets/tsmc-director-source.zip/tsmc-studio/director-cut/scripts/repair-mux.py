"""Join the natively re-rendered 8.0–11.5s handoff into the master.
A full render from the corrected World.tsx also reproduces the corrected motion;
this script preserves the expensive unaffected frames for this delivery.
"""
from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1]
args=['ffmpeg','-y','-hide_banner','-i',str(R/'output/original-pass.mp4'),'-i',str(R/'output/handoff-repair.mp4'),'-filter_complex','[0:v]split=2[head][tail];[head]trim=end_frame=240,setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[tail]trim=start_frame=345,setpts=PTS-STARTPTS[c];[a][b][c]concat=n=3:v=1:a=0[v]','-map','[v]','-map','0:a:0','-c:v','libx264','-crf','17','-preset','medium','-pix_fmt','yuv420p','-r','30','-c:a','copy','-movflags','+faststart',str(R/'output/tsmc-scale-of-possibility.mp4')]
with (R/'evidence/repair-mux.log').open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True)
