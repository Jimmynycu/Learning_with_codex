import urllib.request,urllib.error,json,hashlib,re
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path('/workspace/Learning_with_codex');OUT=ROOT/'tsmc-studio/director-cut/evidence'
base='https://jimmynycu.github.io/Learning_with_codex/';url=base+'?v=director-cut'
asset='assets/tsmc-scale-of-possibility.mp4'
with urllib.request.urlopen(base+asset,timeout=90) as r:
 body=r.read();assert r.status==200 and 'video/mp4' in r.headers['Content-Type'];mime=r.headers['Content-Type']
assert hashlib.sha256(body).digest()==hashlib.sha256((ROOT/'site'/asset).read_bytes()).digest()
with urllib.request.urlopen(urllib.request.Request(base+asset,headers={'Range':'bytes=0-1023'}),timeout=30) as r:assert r.status==206;partial=r.headers.get('Content-Range');r.read()
for relative in ['director-notes.html','studies.html','form-flow.html','assets/tsmc-director-source.zip','director-proof/manifest.json']:
 with urllib.request.urlopen(base+relative,timeout=45) as r:assert r.status==200
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage']);page=browser.new_page(viewport={'width':1440,'height':1050});errors=[];page.on('pageerror',lambda error:errors.append(str(error)));transport='native-browser-https'
 try:page.goto(url,wait_until='domcontentloaded',timeout=15000)
 except Exception as e:
  if not any(s in str(e) for s in ['ERR_CERT_AUTHORITY_INVALID','ERR_TUNNEL_CONNECTION_FAILED']):raise
  transport='Live public HTTPS responses fetched using the system trusted CA bundle and forwarded to the browser; TLS verification retained.'
  def live(route):
   target=route.request.url
   if not target.startswith(base):route.continue_();return
   headers={'Accept-Encoding':'identity'}
   if 'range' in route.request.headers:headers['Range']=route.request.headers['range']
   try:r=urllib.request.urlopen(urllib.request.Request(target,headers=headers),timeout=90)
   except urllib.error.HTTPError as e:r=e
   with r:
    body=r.read();h={k:v for k,v in r.headers.items() if k.lower() not in ['transfer-encoding','connection','content-length']};route.fulfill(status=r.status,headers=h,body=body)
  page.route('**/*',live);page.goto(url,wait_until='domcontentloaded',timeout=90000)
 page.screenshot(path=str(OUT/'live-desktop-poster.png'),full_page=True)
 page.locator('#play').click();page.wait_for_function('document.querySelector("video").currentTime>.5',timeout=60000)
 checkpoints=[]
 for t in [4,10.5,16,24.5]:
  page.locator(f'[data-time="{t}"]').click();page.wait_for_function('(t)=>{const v=document.querySelector("video");return v.currentTime>t+.15 && !v.seeking && v.readyState>=3}',arg=t,timeout=45000)
  checkpoints.append(page.evaluate('document.querySelector("video").currentTime'))
 page.evaluate('const v=document.querySelector("video");v.currentTime=12.7;v.pause()');page.wait_for_function('!document.querySelector("video").seeking')
 state=page.evaluate('()=>{const v=document.querySelector("video");return {src:v.currentSrc,duration:v.duration,width:v.videoWidth,height:v.videoHeight,audioDecodedBytes:v.webkitAudioDecodedByteCount,muted:v.muted,error:v.error,status:document.querySelector("#status").textContent}}')
 assert state['width']==1920 and state['height']==1080 and abs(state['duration']-28)<.1 and state['audioDecodedBytes']>0 and state['error'] is None and not state['muted'],state
 page.screenshot(path=str(OUT/'live-desktop-playing.png'),full_page=True)
 page.set_viewport_size({'width':390,'height':844});assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
 page.screenshot(path=str(OUT/'live-mobile.png'),full_page=True)
 assert not errors,errors
 result={'url':url,'mime':mime,'range':partial,'sha256':hashlib.sha256((ROOT/'site'/asset).read_bytes()).hexdigest(),'transport':transport,'state':state,'chapter_checkpoints':checkpoints,'mobile_no_overflow':True,'javascript_errors':errors}
 (OUT/'live-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));browser.close()
