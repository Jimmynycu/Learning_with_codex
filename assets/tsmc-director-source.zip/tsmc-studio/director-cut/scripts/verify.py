from pathlib import Path
import subprocess,json,re
import numpy as np
ROOT=Path(__file__).resolve().parents[1];FILM=ROOT/'output/tsmc-scale-of-possibility.mp4';OUT=ROOT/'evidence'
if not FILM.exists():raise SystemExit('No final master to verify.')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(FILM)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert v['width']==1920 and v['height']==1080 and int(v['nb_frames'])==840 and v['r_frame_rate']=='30/1'
assert abs(float(v['duration'])-28)<.04 and abs(float(a['duration'])-28)<.08
# Decode all frames, detect extended all-black output, and measure encoded audio.
cmd=['ffmpeg','-hide_banner','-i',str(FILM),'-vf','blackdetect=d=0.2:pix_th=0.02:pic_th=0.98','-af','ebur128=peak=true','-f','null','-']
r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);assert r.returncode==0,r.stderr[-2500:]
(OUT/'full-decode-and-audio.log').write_text(r.stderr)
black=re.findall(r'black_start:([0-9.]+) black_end:([0-9.]+) black_duration:([0-9.]+)',r.stderr)
assert not black,black
# Compare temporal audio energy with the intended score, not merely stream presence.
def pcm(path):
 return np.frombuffer(subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','12000','-f','f32le','-']),dtype='<f4')
x=pcm(FILM);y=pcm(ROOT.parent/'public/director-cut/score.wav');n=min(len(x),len(y));blocks=n//1200
rx=np.sqrt(np.mean(x[:blocks*1200].reshape(blocks,1200)**2,axis=1));ry=np.sqrt(np.mean(y[:blocks*1200].reshape(blocks,1200)**2,axis=1));correlation=float(np.corrcoef(rx,ry)[0,1]);assert correlation>.97,correlation
result={'video':{'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':v['nb_frames'],'seconds':v['duration']},'audio':{'codec':a['codec_name'],'seconds':a['duration'],'score_energy_correlation':correlation},'full_decode_passed':True,'black_intervals':black,'bytes':FILM.stat().st_size}
(OUT/'final-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
