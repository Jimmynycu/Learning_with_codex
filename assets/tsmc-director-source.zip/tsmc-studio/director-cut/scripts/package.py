from pathlib import Path
import zipfile,shutil,json,subprocess,hashlib,html
ROOT=Path(__file__).resolve().parents[2]
SITE=ROOT.parent/'site'
ASSETS=SITE/'assets'
FILM=ROOT/'director-cut/output/tsmc-scale-of-possibility.mp4'
if not FILM.exists():raise SystemExit('Final master not yet rendered; packaging will not use the preview.')
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(FILM)]))
v=next(s for s in probe['streams'] if s['codec_type']=='video');a=next(s for s in probe['streams'] if s['codec_type']=='audio')
assert v['width']==1920 and v['height']==1080 and int(v['nb_frames'])==840 and v['r_frame_rate']=='30/1',v
assert abs(float(v['duration'])-28)<.04 and abs(float(a['duration'])-28)<.08,a
(ROOT/'director-cut/evidence/final-probe.json').write_text(json.dumps(probe,indent=2))
shutil.copy(FILM,ASSETS/FILM.name)
frames={'tsmc-director-poster':12.7,'director-macro':1.8,'director-wafer':5.8,'director-package':12.7,'director-connect':19,'director-resolve':26.8}
for name,t in frames.items():
 subprocess.run(['ffmpeg','-y','-v','error','-ss',str(t),'-i',str(FILM),'-frames:v','1','-q:v','2',str(ASSETS/f'{name}.jpg')],check=True)
# Source archive preserves the exact package versions and all local visual/audio assets.
with zipfile.ZipFile(ASSETS/'tsmc-director-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in ['package.json','package-lock.json','.npmrc']:
  z.write(ROOT/f,f'tsmc-studio/{f}')
 for sub in ['director-cut/src','director-cut/scripts']:
  for p in (ROOT/sub).rglob('*'):
   if p.is_file():z.write(p,'tsmc-studio/'+str(p.relative_to(ROOT)))
 for f in ['director-cut/README.md','director-cut/DIRECTION.md','director-cut/CRITIQUE.md','director-cut/beats.json','director-cut/requirements.txt']:
  z.write(ROOT/f,'tsmc-studio/'+f)
 for p in (ROOT/'public/assets').iterdir():
  if p.suffix in ['.ttf','.png','.txt']:z.write(p,'tsmc-studio/public/assets/'+p.name)
 for f in ['grain.png','score.wav']:z.write(ROOT/'public/director-cut'/f,'tsmc-studio/public/director-cut/'+f)
 for f in ['final-render.log','handoff-repair.log','repair-mux.log','final-probe.json','final-verification.json','audio-analysis.log']:
  p=ROOT/'director-cut/evidence'/f
  if p.exists():z.write(p,'tsmc-studio/director-cut/evidence/'+f)
 proof=ROOT/'evidence/reference-study/REFERENCE-STUDY.md'
 if proof.exists():z.write(proof,'tsmc-studio/evidence/reference-study/REFERENCE-STUDY.md')
publicproof=SITE/'director-proof';publicproof.mkdir(exist_ok=True)
for f in ['README.md','DIRECTION.md','CRITIQUE.md','beats.json','src/World.tsx','src/Film.tsx','scripts/score.py','evidence/final-render.log','evidence/handoff-repair.log','evidence/repair-mux.log','evidence/final-probe.json','evidence/final-verification.json']:
 p=ROOT/'director-cut'/f
 shutil.copy(p,publicproof/(f.replace('/','-')+'.txt'))
manifest={'title':'TSMC — The Scale of Possibility','file':FILM.name,'duration':28,'width':1920,'height':1080,'fps':30,'frames':840,'sha256':hashlib.sha256(FILM.read_bytes()).hexdigest(),'engines':{'Remotion':'4.0.532','Three.js':'0.186.1'}}
(publicproof/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
